//----------------------------------------------------------------
//      _____
//     /     \
//    /____   \____
//   / \===\   \==/
//  /___\===\___\/  AVNET
//       \======/
//        \====/    
//---------------------------------------------------------------
//
// This design is the property of Avnet.  Publication of this
// design is not authorized without written consent from Avnet.
// 
// Please direct any questions to:  technical.support@avnet.com
//
// Disclaimer:
//    Avnet, Inc. makes no warranty for the use of this code or design.
//    This code is provided  "As Is". Avnet, Inc assumes no responsibility for
//    any errors, which may appear in this code, nor does it make a commitment
//    to update the information contained herein. Avnet, Inc specifically
//    disclaims any implied warranties of fitness for a particular purpose.
//                     Copyright(c) 2010 Avnet, Inc.
//                             All rights reserved.
//
//----------------------------------------------------------------
//
// Create Date:         Jan 08, 2010
// Design Name:         FMC-DVIDP
// Module Name:         fmc_dvidp.c
// Project Name:        FMC-DVIDP
// Target Devices:      Spartan-6
// Avnet Boards:        FMC-DVIDP
//
// Tool versions:       ISE 13.1
//
// Description:         FMC-DVIDP Software Services.
//
// Dependencies:        
//
// Revision:            Nov 11, 2009: 1.00 Initial version
//                      Jan 08, 2010: 1.01 Use new fmc_iic library
//                      Mar 17, 2010: 1.02 Add arguments to tfp403/tfo410 config routines
//                      ------------------------------------------
//                      Apr 12, 2011: 2.01 Modify *_usleep() function to prevent hanging
//
//----------------------------------------------------------------

#include <stdio.h>
#include <string.h>

// Located in: microblaze_0/include/
#include "xparameters.h"
#include "xstatus.h"

#include "fmc_iic.h"
#include "fmc_dvidp.h"

////////////////////////////////////////////////////////////////////////
// Driver Initialization
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function initializes the FMC-IMAGEOV driver.
*
* @param    pContext contains a pointer to the new FMC-DVI/DP instance's context.
* @param    szName contains a string describing the new FMC-DVI/DP instance.
* @param    pIIC contains a pointer to a FMC-IIC instance's context.
*
* @return   If successfull, returns 1.  Otherwise, returns 0.
*
* @note     None.
*
******************************************************************************/
int fmc_dvidp_init( fmc_dvidp_t *pContext, char szName[], fmc_iic_t *pIIC )
{
   pContext->pIIC = pIIC;
   strcpy( pContext->szName, szName );

   // Initialize the GPIO bits to known state
   //  [7] = unused
   //  [6] = fmc_dvidp_dvi_rst = 0
   //  [5] = fmc_dvidp_iic_rst# = 1
   //  [4] = unused
   //  [3] = unused
   //  [2] = unused
   //  [1] = unused
   //  [0] = unused
   pContext->GpioData = 0x20;
   pContext->pIIC->fpGpoWrite( pContext->pIIC, pContext->GpioData );

   return 1;
}

////////////////////////////////////////////////////////////////////////
// I2C MUX Functions
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function applies a reset to the I2C MUX.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_iic_mux_reset( fmc_dvidp_t *pContext )
{   
   // Apply reset to I2C mux
   //xil_printf( "Apply reset to I2C mux ...\n\r" );
   // Modify appropriate GPIO bits
   //  [5] = fmc_dvidp_iic_rst# = 0
   pContext->GpioData &= ~0x20;
   pContext->pIIC->fpGpoWrite( pContext->pIIC, pContext->GpioData );
   
   // sleep 1sec
   fmc_dvidp_wait_usec(1000000); 
   
   // Release reset from I2C mux
   //xil_printf( "Release reset from I2C mux ...\n\r" );
   // Modify appropriate GPIO bits
   //  [5] = fmc_dvidp_iic_rst# = 1
   pContext->GpioData |= 0x20;
   pContext->pIIC->fpGpoWrite( pContext->pIIC, pContext->GpioData );
}

/******************************************************************************
* This function configures the PCAxxxx I2C multiplexer.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    MuxSelect specified which of the I2C mux's outputs to enable.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_iic_mux( fmc_dvidp_t *pContext, Xuint32 MuxSelect )
{
   Xuint8 mux_data;
   Xuint8 num_bytes;
   
   switch ( MuxSelect )
   {
      //
      // Single Mux Selections
      //
      case FMC_DVIDP_I2C_SELECT_DVII_EDID:
         mux_data = 0x01;
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_I2C_MUX_ADDR, mux_data, &mux_data, 1); 
         break;
      case FMC_DVIDP_I2C_SELECT_DVIO_EDID:
         mux_data = 0x02;
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_I2C_MUX_ADDR, mux_data, &mux_data, 1); 
         break;
      case FMC_DVIDP_I2C_SELECT_TFP410:
      //case FMC_DVIDP_I2C_SELECT_TFP403:
         mux_data = 0x04;
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_I2C_MUX_ADDR, mux_data, &mux_data, 1); 
         break;
      case FMC_DVIDP_I2C_SELECT_CDCE913:
         mux_data = 0x08;
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_I2C_MUX_ADDR, mux_data, &mux_data, 1); 
         break;
   }
   //xil_printf("[fmc_dvidp_iic_mux] I2C_MUX=%d\n\r", MuxSelect );

}

////////////////////////////////////////////////////////////////////////
// Generic I2C Configuration Functions
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function sends an I2C configuration sequence.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    MuxSelect specified which of the I2C mux's outputs to enable.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_iic_config( fmc_dvidp_t *pContext, Xuint8 ChipAddress, 
                           Xuint8 ConfigData[][2], Xuint32 ConfigLength )
{
   Xuint8 num_bytes;
   int i;

   //xil_printf("I2C[0x%02X] : ");
   for ( i = 0; i < ConfigLength; i++ )
   {
      num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, ChipAddress, ConfigData[i][0], &(ConfigData[i][1]), 1); 
      //if ( num_bytes > 0 ) xil_printf("+"); else xil_printf("-");
   }
   //xil_printf("\n\r");
}

////////////////////////////////////////////////////////////////////////
// CDCE913 Functions
////////////////////////////////////////////////////////////////////////

// CDCE913 
#define MAX_IIC_CDCE913 32
static Xuint8 iic_cdce913[MAX_IIC_CDCE913][2]=
{
   0x00, 0x81, // Byte 00 - 10000001
   0x01, 0x01, // Byte 01 - 00000000
               // [1:0] - Slave Address A[1:0]=01b
   //0x02, 0xB4, // Byte 02 - 10110100
   //0x03, 0x01, // Byte 03 - 00000001
   0x02, 0xB4, // [  7] = M1 = 1 (PLL1 Clock)
               // [1:0] = PDIV1[9:8] = 
   0x03, 0x02, // [7:0] = PDIV1[7:0] = 2
   0x04, 0x02, // Byte 04 - 00000010
   0x05, 0x50, // Byte 05 - 01010000
   0x06, 0x60, // Byte 06 - 01100000
   0x07, 0x00, // Byte 07 - 00000000
   0x08, 0x00, // Byte 08 - 00000000
   0x09, 0x00, // Byte 09 - 00000000
   0x0A, 0x00, // Byte 10 - 00000000
   0x0B, 0x00, // Byte 11 - 00000000
   0x0C, 0x00, // Byte 12 - 00000000
   0x0D, 0x00, // Byte 13 - 00000000
   0x0E, 0x00, // Byte 14 - 00000000
   0x0F, 0x00, // Byte 15 - 00000000
   0x10, 0x00, // Byte 16 - 00000000
   0x11, 0x00, // Byte 17 - 00000000
   0x12, 0x00, // Byte 18 - 00000000
   0x13, 0x00, // Byte 19 - 00000000
   //0x14, 0xED, // Byte 20 - 11101101
   0x14, 0x6D, // [  7] = MUX1 = 0 (PLL1)
               // [  6] = M2 = 1 (PDIV2)
               // [5:4] = M3 = 2 (PDIV3)
   0x15, 0x02, // Byte 21 - 00000010
   //0x16, 0x01, // Byte 22 - 00000001
   //0x17, 0x01, // Byte 23 - 00000001
   0x16, 0x00, // [6:0] = PDIV2 = 0 (reset and stand-by)
   0x17, 0x00, // [6:0] = PDIV3 = 0 (reset and stand-by)
   //0x18, 0x00, // Byte 24 - 00000000
   //0x19, 0x40, // Byte 25 - 01000000
   //0x1A, 0x02, // Byte 26 - 00000010
   //0x1B, 0x08, // Byte 27 - 00001000
               // PLL1 : Fin=27MHz, M=2, N=11, PDIV=2 Fout=74.25MHz
               //        Fvco = 148.5 MHz
               //        P = 4 - int(log2(11/2)) = 4 - 2 = 2
               //        N'= 11 * 2^2 = 44
               //        Q = int(44/2) = 22
               //        R = 44 - 2*22 = 0
   0x18, 0x00, // [7:0] = PLL1_0N[11:4] = 00000000
   0x19, 0xB0, // [7:4] = PLL1_0N[3:0] = 1011
               // [3:0] = PLL1_0R[8:5] = 0000
   0x1A, 0x02, // [7:3] = PLL1_0R[4:0] = 00000
               // [2:0] = PLL1_0Q[5:3] = 010
   0x1B, 0xC9, // [7:5] = PLL1_0Q[2:0] = 110
               // [4:2] = PLL1_0P[2:0] = 010
               // [1:0] = VC01_0_RANGE[1:0] = 01 (125 MHz < Fvco1 < 150 MHz)
   //0x1C, 0x00, // Byte 28 - 00000000
   //0x1D, 0x40, // Byte 29 - 01000000
   //0x1E, 0x02, // Byte 30 - 00000010
   //0x1F, 0x08, // Byte 31 - 00001000
               // PLL1 : Fin=27MHz, M=2, N=11, PDIV=2 Fout=74.25MHz
               //        Fvco = 148.5 MHz
               //        P = 4 - int(log2(11/2)) = 4 - 2 = 2
               //        N'= 11 * 2^2 = 44
               //        Q = int(44/2) = 22
               //        R = 44 - 2*22 = 0
   0x1C, 0x00, // [7:0] = PLL1_1N[11:4] = 00000000
   0x1D, 0xB0, // [7:4] = PLL1_1N[3:0] = 1011
               // [3:0] = PLL1_1R[8:5] = 0000
   0x1E, 0x02, // [7:3] = PLL1_1R[4:0] = 00000
               // [2:0] = PLL1_1Q[5:3] = 010
   0x1F, 0xC9  // [7:5] = PLL1_1Q[2:0] = 110
               // [4:2] = PLL1_1P[2:0] = 010
               // [1:0] = VC01_1_RANGE[1:0] = 01 (125 MHz < Fvco1 < 150 MHz)
};

//////////////////////////////////////////
// 25.175000 MHz
//////////////////////////////////////////
// PLL1: M = 270, N = 1007, Pdiv = 4
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 100.700000MHz
//       Range = 0 (Fvco < 125 MHz)
//       Fout = Fvco / Pdiv = 25.175000MHz
//       P = 4 - int(log2(M/N)) = 3
//       Np = N * 2^P = 8056
//       Q = int(Np/M) = 29
//       R = Np - M*Q = 226
static Xuint8 iic_cdce913_y1_config_25_175_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x04,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x3E,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0xF7,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x13,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0xAC    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//////////////////////////////////////////
// 27.000000 MHz
//////////////////////////////////////////
// PLL1: M = 1, N = 1, Pdiv = 1
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 27.000000MHz
//       Range = 0 (Fvco < 125 MHz)
//       Fout = Fvco / Pdiv = 27.000000MHz
//       P = 4 - int(log2(M/N)) = 4
//       Np = N * 2^P = 16
//       Q = int(Np/M) = 16
//       R = Np - M*Q = 0
static Xuint8 iic_cdce913_y1_config_27_000_000[6][2] = 
{
   0x02, 0x34,   // [  7] = M1 = 0 (PLL1 bypassed) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x01,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x00,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0x10,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x02,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0x10    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//ERROR => Fvco = 80.000000MHz <= 100MHz !
//////////////////////////////////////////
// 40.000000 MHz
//////////////////////////////////////////
// PLL1: M = 27, N = 80, Pdiv = 2
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 80.000000MHz
//       Range = 0 (Fvco < 125 MHz)
//       Fout = Fvco / Pdiv = 40.000000MHz
//       P = 4 - int(log2(M/N)) = 3
//       Np = N * 2^P = 640
//       Q = int(Np/M) = 23
//       R = Np - M*Q = 19
static Xuint8 iic_cdce913_y1_config_40_000_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x02,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x05,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0x00,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x9A,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0xEC    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//////////////////////////////////////////
// 65.000000 MHz
//////////////////////////////////////////
// PLL1: M = 27, N = 130, Pdiv = 2
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 130.000000MHz
//       Range = 1 (125 MHz <= Fvco < 150 MHz)
//       Fout = Fvco / Pdiv = 65.000000MHz
//       P = 4 - int(log2(M/N)) = 2
//       Np = N * 2^P = 520
//       Q = int(Np/M) = 19
//       R = Np - M*Q = 7
static Xuint8 iic_cdce913_y1_config_65_000_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x02,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x08,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0x20,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x3A,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0x69    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//////////////////////////////////////////
// 74.250000 MHz
//////////////////////////////////////////
// PLL1: M = 2, N = 11, Pdiv = 2
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 148.500000MHz
//       Range = 1 (125 MHz <= Fvco < 150 MHz)
//       Fout = Fvco / Pdiv = 74.250000MHz
//       P = 4 - int(log2(M/N)) = 2
//       Np = N * 2^P = 44
//       Q = int(Np/M) = 22
//       R = Np - M*Q = 0
static Xuint8 iic_cdce913_y1_config_74_250_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x02,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x00,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0xB0,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x02,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0xC9    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//////////////////////////////////////////
// 110.000000 MHz
//////////////////////////////////////////
// PLL1: M = 27, N = 110, Pdiv = 1
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 110.000000MHz
//       Range = 0 (Fvco < 125 MHz)
//       Fout = Fvco / Pdiv = 110.000000MHz
//       P = 4 - int(log2(M/N)) = 2
//       Np = N * 2^P = 440
//       Q = int(Np/M) = 16
//       R = Np - M*Q = 8
static Xuint8 iic_cdce913_y1_config_110_000_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x01,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x06,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0xE0,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x42,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0x08    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//////////////////////////////////////////
// 148.500000 MHz
//////////////////////////////////////////
// PLL1: M = 2, N = 11, Pdiv = 1
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 148.500000MHz
//       Range = 1 (125 MHz <= Fvco < 150 MHz)
//       Fout = Fvco / Pdiv = 148.500000MHz
//       P = 4 - int(log2(M/N)) = 2
//       Np = N * 2^P = 44
//       Q = int(Np/M) = 22
//       R = Np - M*Q = 0
static Xuint8 iic_cdce913_y1_config_148_500_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x01,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x00,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0xB0,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x02,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0xC9    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};

//////////////////////////////////////////
// 162.000000 MHz
//////////////////////////////////////////
// PLL1: M = 1, N = 6, Pdiv = 1
//       Fin  = 27.000000MHz
//       Fvco = Fin * N/M = 162.000000MHz
//       Range = 2 (150 MHz <= Fvco < 175 MHz)
//       Fout = Fvco / Pdiv = 162.000000MHz
//       P = 4 - int(log2(M/N)) = 2
//       Np = N * 2^P = 24
//       Q = int(Np/M) = 24
//       R = Np - M*Q = 0
static Xuint8 iic_cdce913_y1_config_162_000_000[6][2] = 
{
   0x02, 0xB4,   // [  7] = M1 = 1 (PLL1 clock) 
                 // [1:0] = Pdiv1[9:8] 
   0x03, 0x01,   // [7:0] = Pdiv1[7:0] 
   0x18, 0x00,   // [7:0] = PLL1_0N[11:4] 
   0x19, 0x60,   // [7:4] = PLL1_0N[3:0]  
                 // [3:0] = PLL1_0R[8:5]  
   0x1A, 0x03,   // [7:3] = PLL1_0R[4:0]  
                 // [2:0] = PLL1_0Q[5:3]  
   0x1B, 0x0A    // [7:5] = PLL1_0Q[2:0] 
                 // [4:2] = PLL1_0P[2:0]  
                 // [1:0] = VCO1_0_RANGE[1:0] 
};


/******************************************************************************
* This function configures the CDCE913 video clock synthesizer.
* The CDCE913 has 3 outputs which are configured as follows:
*    Y1 => 74.25 MHz
*    Y2 => off
*    Y3 => off
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_config_cdce913( fmc_dvidp_t *pContext )
{
   int dev;
   Xuint8 xdata;
   Xuint8 num_bytes;
   int i;

   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_CDCE913 );

   /*
    * Send I2C config sequence
    */
   for ( i = 0; i < MAX_IIC_CDCE913; i++ )
   {
      num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC,
         FMC_DVIDP_CDCE913_ADDR, 
         (0x80 | iic_cdce913[i][0]), &(iic_cdce913[i][1]), 1); 
      //xil_printf("[fmc_dvidp_config_cdce913] CDCE913[0x%02X] <= 0x%02X\n\r",(0x80 | iic_cdce913[i][0]), (iic_cdce913[i][1]));
      //num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC,
      //   FMC_DVIDP_CDCE913_ADDR, 
      //   (0x80 | iic_cdce913[i][0]), &xdata, 1); 
      //xil_printf("[fmc_dvidp_config_cdce913] CDCE913[0x%02X] => 0x%02X\n\r",(0x80 | iic_cdce913[i][0]), xdata);
   }
}

/******************************************************************************
* This function configures the CDCE913 video clock synthesizer's Y1 output.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    FreqId contains the id of the frequency to configure.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_config_cdce913_y1_freq( fmc_dvidp_t *pContext, Xuint32 FreqId )
{
   int dev;
   Xuint8 num_bytes;
   int i;

   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_CDCE913 );

   switch ( FreqId )
   {
   case FMC_DVIDP_CDCE913_FREQ_25_175_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_25_175_000[i][0]), &(iic_cdce913_y1_config_25_175_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_27_000_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_27_000_000[i][0]), &(iic_cdce913_y1_config_27_000_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_40_000_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_40_000_000[i][0]), &(iic_cdce913_y1_config_40_000_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_65_000_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_65_000_000[i][0]), &(iic_cdce913_y1_config_65_000_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_74_250_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_74_250_000[i][0]), &(iic_cdce913_y1_config_74_250_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_110_000_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_110_000_000[i][0]), &(iic_cdce913_y1_config_110_000_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_148_500_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_148_500_000[i][0]), &(iic_cdce913_y1_config_148_500_000[i][1]), 1); 
      }
      break;
   case FMC_DVIDP_CDCE913_FREQ_162_000_000:
      for ( i = 0; i < 6; i++ )
      {
         num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_CDCE913_ADDR, 
            (0x80 | iic_cdce913_y1_config_162_000_000[i][0]), &(iic_cdce913_y1_config_162_000_000[i][1]), 1); 
      }
      break;
   }
}

////////////////////////////////////////////////////////////////////////
// CDCM61002 Functions
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function configures the CDCM61002 video clock synthesizer's outputs.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    FreqId contains the id of the frequency to configure.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_config_cdcm61002_freq( fmc_dvidp_t *pContext, Xuint32 FreqId )
{
   Xuint8 reg_addr;
   Xuint8 reg_data;
   Xuint8 num_bytes;
   int i;

   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_PCA9555 );

   // Configure direction of PCA9555's P1x GPIO pins
   reg_addr = 0x07;
   num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   //xil_printf( "[fmc_dvidp_config_cdcm61002_freq] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   reg_data = 0x00; // P10 => PR[1] (output)
                    // P11 => PR[0] (output)
                    // P12 => OD[2] (output)
                    // P13 => OD[1] (output)
                    // P14 => OD[0] (output)
                    // P15 => RSTN# (output)
                    // P16 => OS[0] (output)
                    // P17 => OS[1] (output)
   //xil_printf( "[fmc_dvidp_config_cdcm61002_freq] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   
   // Configure output values of PCA9555's P0x GPIO pins
   reg_addr = 0x03;
   num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   //xil_printf( "[fmc_dvidp_config_cdcm61002_freq] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   
   // Frequency settings
   switch ( FreqId )
   {
   case FMC_DVIDP_CDCM61002_FREQ_108_000_000:
      reg_data = 0x00   // 108 MHz settings : 27MHz * 24 / 6 = 108 MHz
               | (1<<6) // OS[1:0] =  01 (LVDS outputs, OSC_OUT disabled)
               | (1<<5) // RSTN#   =   1 (de-asserted)
               | (0<<0) // PR[1:0] =  00 (Prescaler = 24)
               | (5<<2) // OD[2:0] = 101 (Output Divider = 6)
               ;
      break;
   case FMC_DVIDP_CDCM61002_FREQ_135_000_000:
      reg_data = 0x00   // 135 MHz settings : 27 MHz * 20 / 4 = 135 MHz
               | (1<<6) // OS[1:0] =  01 (LVDS outputs, OSC_OUT disabled)
               | (1<<5) // RSTN#   =   1 (de-asserted)
               | (3<<0) // PR[1:0] =  11 (Prescaler = 20)
               | (6<<2) // OD[2:0] = 011 (Output Divider = 4)
               ;
      break;
   }
   //xil_printf( "[fmc_dvidp_config_cdcm61002_freq] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 

   // Assert RSTN#
   reg_data &= ~(1<<5); // RSTN#   =   0 (asserted)
   //xil_printf( "[fmc_dvidp_config_cdcm61002_freq] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   
   // wait 100 msec
   fmc_dvidp_wait_usec(100000); 
   
   // De-assert RSTN#
   reg_data |= (1<<5);  // RSTN#   =   1 (de-asserted)
   //xil_printf( "[fmc_dvidp_config_cdcm61002_freq] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
}

////////////////////////////////////////////////////////////////////////
// TFP410 Functions
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function configures the TFP410 TMDS serializer.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    Enable will activate the TFP410 device (when 0, the device is powered-down).
* @param    DeSkew will confifure the TFP410's programmable input data de-skew.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_config_tfp410( fmc_dvidp_t *pContext, Xuint32 Enable, Xuint32 DeSkew )
{
   Xuint8 dvi_data;
   Xuint8 num_bytes;

   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_TFP410 );

   num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_TFP410_ADDR, 0x08, &dvi_data, 1); 
   //xil_printf( "[fmc_dvidp_config_tfp410] TFP410[0x08] <= 0x%02X\n\r", dvi_data );
   if ( Enable )
   {
      dvi_data |=  0x01; // PDN# = 1 (active)
   }
   else
   {
      dvi_data &=  ~0x01; // PDN# = 0 (power down)
   }
   dvi_data |=  0x02; // EDGE = 1
   dvi_data &= ~0x04; // BSEL = 0 (12-bit dual-edge mode)
   dvi_data &= ~0x08; // DSEL = 0 (single-ended clock)
   //xil_printf( "[fmc_dvidp_config_tfp410] TFP410[0x08] <= 0x%02X\n\r", dvi_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_TFP410_ADDR, 0x08, &dvi_data, 1); 

   // Adjust de-skewing delay on DVI_OUT_DATA[11:0]
   dvi_data = DeSkew;
   //xil_printf( "[fmc_dvidp_config_tfp410] TFP410[0x0A] <= 0x%02X\n\r", dvi_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_TFP410_ADDR, 0x0A, &dvi_data, 1); 
   
}

/******************************************************************************
* This function resets the TFP410 TMDS serializer.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_reset_tfp410( fmc_dvidp_t *pContext )
{
   // Apply reset to I2C mux
   //xil_printf( "Apply reset to I2C mux ...\n\r" );
   // Modify appropriate GPIO bits
   //  [6] = fmc_dvidp_dvi_rst = 0
   pContext->GpioData |= 0x40;
   pContext->pIIC->fpGpoWrite( pContext->pIIC, pContext->GpioData );
   
   // sleep 1sec
   fmc_dvidp_wait_usec(1000000); 
   
   // Release reset from I2C mux
   //xil_printf( "Release reset from I2C mux ...\n\r" );
   // Modify appropriate GPIO bits
   //  [6] = fmc_dvidp_dvi_rst = 0
   pContext->GpioData &= ~0x40;
   pContext->pIIC->fpGpoWrite( pContext->pIIC, pContext->GpioData );
}

////////////////////////////////////////////////////////////////////////
// TFP403 Functions
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function configures the TFP403 TMDS de-serializer.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    Enable will activate the TFP403 device (when 0, the device is powered-down).
* @param    OckInv will invert the TFP403's output clock.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void fmc_dvidp_config_tfp403( fmc_dvidp_t *pContext, Xuint32 Enable, Xuint32 OckInv )
{
   Xuint8 reg_addr;
   Xuint8 reg_data;
   Xuint8 num_bytes;

   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_PCA9555 );

   // Configure direction of PCA9555's P0x GPIO pins
   reg_addr = 0x06;
   //num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   //xil_printf( "[fmc_dvidp_config_tfp403] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   reg_data = 0xF1; // PO0 => SCDT    = 1 (input )
                    // PO1 => ST      = 0 (output)
                    // PO2 => PD#     = 0 (output)
                    // PO3 => OCK_INV = 0 (output)
   //xil_printf( "[fmc_dvidp_config_tfp403] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   
   // Configure output values of PCA9555's P0x GPIO pins
   reg_addr = 0x02;
   //num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   //xil_printf( "[fmc_dvidp_config_tfp403] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   reg_data = 0x00;     // PO0 => SCDT    = x
                        // PO1 => ST      = 0 (low drive strength)
                        // PO2 => PD#     = 0 (power down)
                        // PO3 => OCK_INV = 0 (latch data on falling ODCK edge)
   if ( Enable == FMC_DVIDP_TFP403_ENABLED )
   {
      reg_data |= 0x04; // PO2 => PD#     = 1 (normal operation)
   }
   if ( OckInv == FMC_DVIDP_TFP403_OCK_INVERTED )
   {
      reg_data |= 0x08; // PO3 => OCK_INV = 1 (latch data on rising ODCK edge)
   }
   //xil_printf( "[fmc_dvidp_config_tfp403] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   num_bytes = pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 

}

/******************************************************************************
* This function reads the TFP403's sync detect status pin.
*
* @param    pContext contains a pointer to a FMC-DVI/DP instance's context.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
int fmc_dvidp_detect_tfp403( fmc_dvidp_t *pContext )
{
   Xuint8 reg_addr;
   Xuint8 reg_data;
   Xuint8 num_bytes;
   int sync_detect;

   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_PCA9555 );

   // Read input values of PCA9555's P0x GPIO pins
   reg_addr = 0x00;
   num_bytes = pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_PCA9555_ADDR, reg_addr, &reg_data, 1); 
   //xil_printf( "[fmc_dvidp_detect_tfp403] PCA9555[0x%02X] <= 0x%02X\n\r", reg_addr, reg_data );
   
   sync_detect = (reg_data & 0x01);
   
   return sync_detect;
}

////////////////////////////////////////////////////////////////////////
// DDC/EDID Functions
////////////////////////////////////////////////////////////////////////

/******************************************************************************
* This function reads the contents of the DVI input's EDID EEPROM.
*
* @param    pContext contains a pointer to a FMC-DVI/DP instance's context.
* @param    pData contains a vector where the EDID EEPROM are stored.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
int fmc_dvidp_read_dvii_edid( fmc_dvidp_t *pContext, Xuint8 pData[256] )
{
   Xuint8 num_bytes = 0;
   int    idx;
   
   // Mux Selection
   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_DVII_EDID );

   // Read contents of EDID EEPROM
   for ( idx = 0; idx < 256; idx++ )
   {
      num_bytes += pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_DDCEDID_ADDR, idx, &pData[idx], 1); 
   }
   
   return num_bytes;
}

/******************************************************************************
* This function writes the contents of the DVI input's EDID EEPROM.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    pData contains a vector containing new EDID EEPROM data.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
int fmc_dvidp_write_dvii_edid( fmc_dvidp_t *pContext, Xuint8 pData[256] )
{
   Xuint8 num_bytes = 0;
   //Xuint8 dummy_data;
   int    idx;
   
   // Mux Selection
   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_DVII_EDID );

   // Read contents of EDID EEPROM
   for ( idx = 0; idx < 256; idx++ )
   {
      num_bytes += pContext->pIIC->fpIicWrite( pContext->pIIC, FMC_DVIDP_DDCEDID_ADDR, idx, &pData[idx], 1); 

	  fmc_dvidp_wait_usec(1000);
      // Read new value (kills time)
      //pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_DDCEDID_ADDR, idx, &dummy_data, 1); 
      //if ( !(idx%8) ) xil_printf( "\n\r\t[0x%02X] ", idx );
      //xil_printf( "0x%02X ", pData[idx] );

   }
   xil_printf( "\n\r" );

   return num_bytes;
}

/******************************************************************************
* This function reads the contents of the DVI output's EDID EEPROM.
*
* @param    pContext contains a pointer to the FMC-DVI/DP instance's context.
* @param    pData contains a vector where the EDID EEPROM are stored.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
int fmc_dvidp_read_dvio_edid( fmc_dvidp_t *pContext, Xuint8 pData[256] )
{
   Xuint8 num_bytes = 0;
   int    idx;
   
   // Mux Selection
   fmc_dvidp_iic_mux( pContext, FMC_DVIDP_I2C_SELECT_DVIO_EDID );

   // Read contents of EDID EEPROM
   for ( idx = 0; idx < 256; idx++ )
   {
      num_bytes += pContext->pIIC->fpIicRead( pContext->pIIC, FMC_DVIDP_DDCEDID_ADDR, idx, &pData[idx], 1); 
   }
   
   return num_bytes;
}

////////////////////////////////////////////////////////////////////////
// Delay Functions
////////////////////////////////////////////////////////////////////////

/***********************************************************************
* Wait the specified number of microseconds
*
* @param    delay specifies the number of microseconds to wait.
*
* @return   None. 
*
* @note     Call external usleep() function, supplied by user application
*
***********************************************************************/
extern void usleep(unsigned int useconds);
void fmc_dvidp_wait_usec(unsigned int delay) {
#if SIM
  // no delay for simulation
  return;
#endif

  usleep(delay);
}

